
mask_600 - v1 2020-10-28 7:52pm
==============================

This dataset was exported via roboflow.ai on October 28, 2020 at 11:59 AM GMT

It includes 710 images.
Mask-600 are annotated in COCO format.

The following pre-processing was applied to each image:

No image augmentation techniques were applied.


