
mask - v1 2020-10-27 3:04pm
==============================

This dataset was exported via roboflow.ai on October 27, 2020 at 7:08 AM GMT

It includes 46 images.
Mask are annotated in COCO format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


