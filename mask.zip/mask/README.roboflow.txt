
mask - v1 2020-10-28 4:05pm
==============================

This dataset was exported via roboflow.ai on October 28, 2020 at 8:05 AM GMT

It includes 46 images.
Mask are annotated in COCO format.

The following pre-processing was applied to each image:

No image augmentation techniques were applied.


